from fastapi import APIRouter, HTTPException
from app.twelvedata_client import obter_sinal
from app.telegram_bot import enviar_telegram
import asyncio

router = APIRouter()

BOT_ATIVO = False

@router.get("/live")
async def sinal_live():
    sinal = await obter_sinal()
    if not sinal:
        raise HTTPException(status_code=404, detail="Nenhum sinal disponível ainda")
    return {"status": "ok", "sinal": sinal}

@router.post("/bot/status")
async def alternar_bot(body: dict):
    global BOT_ATIVO
    BOT_ATIVO = body.get("ativo", False)
    return {"bot_status": BOT_ATIVO, "msg": "Bot atualizado com sucesso"}

async def ciclo_automatico():
    global BOT_ATIVO
    while True:
        if BOT_ATIVO:
            sinal = await obter_sinal()
            if sinal and sinal["confianca"] >= 90:
                msg = (
                    f"📊 *IA do Imperador 4.0*\n\n"
                    f"💹 Ativo: {sinal['ativo']}\n"
                    f"📈 Sinal: {sinal['sinal']}\n"
                    f"📊 Confiança: {sinal['confianca']}%"
                )
                await enviar_telegram(msg)
        await asyncio.sleep(300)
